--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: php1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.php1 (
    "Salary" character varying(50),
    "Job_Title" character varying(50),
    "Company" character varying(50),
    "KeySkill" character varying(50)
);


ALTER TABLE public.php1 OWNER TO postgres;

--
-- Data for Name: php1; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.php1 VALUES ('$300', 'UI/UX Developer', 'Xento System', NULL);
INSERT INTO public.php1 VALUES ('$500,', 'Frontend Development', 'Facebook', NULL);
INSERT INTO public.php1 VALUES ('$500,$300,', 'PHP Developer', 'Xento Systems', NULL);
INSERT INTO public.php1 VALUES ('$300,', 'UI/UX Designer', 'Faceboook', 'HTML');


--
-- PostgreSQL database dump complete
--

