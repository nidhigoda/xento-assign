<!DOCTYPE html> 
<html>
    <head>
        <title>HTML ASS3</title>
        <link rel="stylesheet" href="htmlass3.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       <script>
           function myfun()
           {
               window.open("fd.html");
           }
       </script>
       
    </head>
    <body>
        <?php $conn=pg_connect("host=localhost dbname=postgres user=postgres password=Nidhigoda");?>
        <div class="div1">
            <div class="start" >
                <b>Jobpply</b>
                <nav class="nav1">
                    <li >
                        <a href="">Home</a>
                        <a href="">About</a>
                        <a href="">Candidate</a>
                        <a href="">Blog</a>
                        <a href="">Contact</a>
                        <button  class="a1" >Post a Job</button>
                        <button class="a2">Want a Job</button>
                    </li>
                   
                </nav>
            </div>
            <div class="div2">
                <p style="font-size: x-small;"><b>Home></b><span style="padding-left: 15px;"><b>New Job Post</b></span></p>
                <b style="font-size:xx-large;">Post a Job</b>
            </div>
        </div>
        <div class="div3">
            
            <div class="ass3">
                <p >Recently Added Jobs</p>
                <b>Hot Jobs</b>
                <div class="divparts">
                    <?php
                    $sql="SELECT * FROM php1";
                    $res=pg_query($sql);
                    while($row=pg_fetch_assoc($res))
                    {
                        echo '<b>';
                        $a= $row['Job_Title'];
	      echo $a;
                        echo '</b>';
                        
                        

                    ?>
                   
                    <button style="background-color: slateblue;" class="btn1"><?php echo $row['Job_Type'];?></button>
                   
                  
                    <a href="del.php?id=<?php echo $a;?>">Delete</a>
                    
                    <span class="dot" style="padding-top:3px;color:#DC143C;">&#10084;</span>
                    <button class="apply">Apply Job</button><br/>
                    <i class="fa fa-mortar-board" style="font-size:10px;display:inline-block;"></i>
                    <span class="blue"><?php echo $row['Company']; ?></span>
                    <i class="fa fa-crosshairs" style="font-size:10px;display: inline-block;padding-left:6px;">WESTERN CITY,UK</i>
                    <hr style="background-color: tomato; size: 1px;" >
                    <?php
                        }
 
                    ?>
                </div>
               
                
            </div>
                
         </div>
    </body>
    <footer>
        <div class="foot1">
            <h1>Subscribe to our Newsletter</h1>
            <b>Far far away,behind the word mountains.far from the countries Vokalia <br/>and
                Consonantia,there live the blind texts.Separated they live in</b><br/>
                <input type="email" placeholder="Enter Email adress"/>
                <button>Subscribe</button>
        </div>
    </footer>
</html>