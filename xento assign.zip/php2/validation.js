function validate(){
    var title1 = stdreg.jobtitle.value;
    var company = stdreg.company.value;
    var location = stdreg.location.value;
    var job = stdreg.job.value;
   
    var flag = false;
    var str = "";
    var regexp = /^[A-Za-z]+$/

    if(title1.trim()===""||title1.length<4){
        flag=true;
        str +=" Job title must contain 3 letters!!\n";
    }

    if(!regexp.test(title1)){
        flag=true;
        str +=" Job title should not contain any number or special character!!!\n";
    }
   
    if(company.trim()===""||company.length<4){
        flag = true;
        str += "  company must contain 3 letters!!\n";
    }
    if(location.trim()===""||location.length<4){
        flag=true;
        str += "  location must contain 3 letters!!\n";
    }
     if(job.trim()===""||job.length<4){
        flag=true;
        str += " Job must contain 3 letters!!\n";
    }
   
    if(flag){
        alert("Warning!!\n"+str);
        return false;
    }
    else{
        return true;
    }
}

