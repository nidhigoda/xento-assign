<!DoCTYPE html>
<head>
    <title>HTML ASS2</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <script  src="validation.js">
 
            function checkButton(){
               if(document.stdreg.b1.checked ==true){
                   alert("Box1 is checked");
               } else if(document.form1.b2.checked ==true){
                   alert("Box 2 is checked");
               }
           }
       </script>
        <style>
            .div1{
                width:1000px;
                height:400px;
                background-image: url("bg_1.jpg");
                background-size: cover;
                padding-left: 100px;
                margin-top: 50px;
                margin-left: 50px;
                margin-right: 50px;
                
            }
            .start{
            padding:20px;
        }
        .nav1>li>a{
            color:black;
            text-decoration: none;
            padding:10px;
        }
        .nav1>li>a:hover{
                color:blue;
        }
        .a1{
            color:white;
            background-color: blue;
            height: 30px;
            border-radius: 5px;
            border-color: blue;
    
            
        }
        .a2{
            color:white;
            background-color: red;
            height: 30px;
            border-radius: 5px;
            border-color: red;
        }
        li{
            display:inline-block;
        }
        .nav1{
            float:right;
            
        }
        .div2{
            padding-top: 210px;
            padding-left: 100px;
        }
        .div3{
            margin-right: 50px;
            width: 1100px;
            height: 800px;
            margin-left: 50px;
            background-color:gainsboro;
        }
        .split{
            height: 100%;
            width: 40%;
            position: absolute;
            z-index: 1;
            top: 10;
            
           padding-top: 20px;
          
        }
        .left{
        
        }
        .right{
            right: 0;
        }
        .centered{
            position: absolute;
  
  
  
        }
        .form1{
            background-color: white;
            border-radius: 2px;
           padding:50px;
           margin-left: 100px;
            
            
        }
        .form1 form{
          width: 300px;
            
        
        }

        .form2{
            background-color: white;
            border-radius: 2px;
            width: 250px;
            margin:20px;
           padding: 10px;
            
        }
       .text1{
           width:290px;
       }
       .form1 button{
           background-color: blueviolet;
           color: white;
           border: none;
           border-radius: 2px;
           height: 40px;
           width: 60px;
       }
       .section1{
           border-radius: 3px;
           padding-top:  10px;
           background-color: white;
            border-radius: 2px;
            width: 250px;
            margin:20px;
           padding: 10px;
       }
       .section1 input{
           padding: 5px;
           color: white;
           background-color: blueviolet;
           border-radius: 3px;
           margin: 10px;
           border: none;
           height: 30px;

       }
       .foot1{
           background-color: blueviolet;
           height: 300px;
           width:1060px;
           margin-left: 50px;
           text-align: center;
           color: white;
           padding: 20px;
       }
       .foot1 input{
        height:30px;
        width: 500px;
        border-radius: 10px;
        background-color: white;
        color:black;
        margin: 20px;
        margin-right: 0px;
        border:none;
       }
       .foot1 button{
           height: 30px;
           background-color: red;
           border: none;
           color: white;
           border-radius: 5px;
           margin: 0px;
           
       }
       .error{
           color:red;
       }
        </style>
</head>
<body>
    <?php
    $jobtitleerr=$companyerr=$locationerr=$jobdescriptionerr=$jobtyperr="";
    $jobtitle=$company=$location=$jobdescription=$jobtype="";
    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        if(empty($_POST["jobtitle"]))
        {
            $jobtitleerr="Job Title is Required";
        }
        else
        {
            $jobtitle=test_input($_POST["jobtitle"]);
        }
        if(empty($_POST["company"]))
        {
            $companyerr="Company Name is Required";
        }
        else
        {
            $company=test_input($_POST["company"]);
        }
        if(empty($_POST["location"]))
        {
            $locationerr="location is Required";
        }
        else
        {
            $location=test_input($_POST["location"]);
        }
        if(empty($_POST["job"]))
        {
            $jobdescriptionerr="Job Description is Required";
        }
        else
        {
            $jobdescription=test_input($_POST["job"]);
        }
        if(empty($_POST["1"]))
        {
            $jobtyperr="Job Type is Required";
        }
        else
        {
            $jobtype=test_input($_POST["1"]);
        }
 
        
    }
    function test_input($data)
{
  $data=trim($data);
  $data=stripslashes($data);
  $data=htmlspecialchars($data);
  return $data;
}
    ?>
    <div class="div1">
        <div class="start" >
            <b>Jobpply</b>
            <nav class="nav1">
                <li >
                    <a href="">Home</a>
                    <a href="">About</a>
                    <a href="">Candidate</a>
                    <a href="">Blog</a>
                    <a href="">Contact</a>
                    <button  class="a1" >Post a Job</button>
                    <button class="a2">Want a Job</button>
                </li>
               
            </nav>
        </div>
        <div class="div2">
            <p style="font-size: x-small;"><b>Home></b><span style="padding-left: 15px;"><b>New Job Post</b></span></p>
            <b style="font-size:xx-large;">Post a Job</b>
        </div>
    </div>
    <div class="div3">
       <div class="split left">
           <div class="centered">
            <div class="form1">
                <form name="stdreg"  method="post"action= "<?php echo htmlspecialchars($_SERVER["PHP_SELF"])?>" >
                    <input type="checkbox"name="chk[]" value="$500" />
                    <label >$500 for 30 day</label><br/>
                    <input  type="checkbox"name="chk[]" value="$300" />
                    <label  >$300/Monthly recurring</label><br/>
                    <br/>
                    <label>Job Title</label><br/>
                    <input class="text1" type="text" name="jobtitle" placeholder="Eg. Graphixs"value="<?php if(isset($_POST['jobtitle'])) {echo $_POST['jobtitle'];}?>"/><span class="error"><?php echo $jobtitleerr ?></span>
                    <br/><br/>
                    
                    <label>Company</label><br/>
                    <input class="text1" type="text" name="company" placeholder="Eg. Facebook, etc "value="<?php if(isset($_POST['company'])) {echo $_POST['company'];}?>"/><span class="error"><?php echo $companyerr ?></span>
                    <br/><br/>
                    <label>Job type</label><br/>
                    <input type="radio" name="1" value="Full time" <?php if (isset($jobtype) && $jobtype=="Full time") echo "checked";?>/>Full Time<br/>
                    <input type="radio" name="1" value="Part time" <?php if (isset($jobtype) && $jobtype=="Part time") echo "checked";?>/>Part Time<br/>
                    <input type="radio" name="1"<?php if (isset($jobtype) && $jobtype=="Freelance") echo "checked";?> value="Freelance"/>Freelance<br/>
                    <input type="radio" name="1"<?php if (isset($jobtype) && $jobtype=="Internship") echo "checked";?> value="Internship"/>Internship<br/>
                    <input type="radio" name="1" <?php if (isset($jobtype) && $jobtype=="Temp") echo "checked";?> value="Temp"/>Temporary<br/><span class="error"><?php echo $jobtyperr ?></span>
                    <br/>
                    <label>Location</label><br/>
                    <input class="text1" name="location" type="text" placeholder="Eg. Facebook, etc "value="<?php if(isset($_POST['location'])) {echo $_POST['location'];}?>"/><span class="error"><?php echo $locationerr ?></span><br/><br/>
                    <label>Job Description</label><br/>
                    <textarea name="job" class="text1" rows="5"value="<?php if(isset($_POST['job'])) {echo $_POST['job'];}?>"></textarea><span class="error"><?php echo $jobdescriptionerr ?></span><br/><br/>
                    <button style="background-color: blue;"  name="btn" onclick="return validate();">Post</button>
                   
                </form>
            </div>
           </div>
        
       </div>
       <div class="split right">
           <div class="form2">
              
           <b>Contact Info </b>
           <br/><br/>
           <p style="color:lightgrey">Address <br/>203 Fake St. Mountain View,San
            Francisco,California,USA
           </p>
           <b>Phone</b>
           <p style="color: blueviolet;">+1 2323235324</p>
           <b>Email Address</b>
           <p style="color:blueviolet">[email protected]</p>
           
           
           </div>
           <div class="section1">
               <b>More Info</b>
            <p>Lorem ipsum dolor sit amet,consectular
            adipisicing edit. lpsa and iure porro mollitia
            architecto hic consequuntur. Distinctio nisi
            perferendis dolore,ipsa consectetur.
            </p>
            <input type="button" value="Learn More"/>
           </div>
       
       </div>
    </div>

</body>
<footer>
    
    <div class="foot1">
        <h1>Subscribe to our Newsletter</h1>
        <b>Far far away,behind the word mountains.far from the countries Vokalia <br/>and
            Consonantia,there live the blind texts.Separated they live in</b><br/>
            <input type="email" placeholder="Enter Email adress"/>
            <button>Subscribe</button>
    </div>
</footer>